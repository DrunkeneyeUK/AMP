AMP Battery Calculator — Netlify deploy folder

1. Unzip this folder.
2. Drag the WHOLE FOLDER onto netlify.com/drop — not the single HTML file.
   The icon only works when these image files sit next to index.html.
3. On the phone: open the site in Safari, Share > Add to Home Screen.

If the old generic "A" icon persists: delete the old home screen shortcut,
fully close Safari (swipe it away), then add it again.
